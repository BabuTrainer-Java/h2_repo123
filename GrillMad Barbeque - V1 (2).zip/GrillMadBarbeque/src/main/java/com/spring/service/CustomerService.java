//package com.spring.service;
//
//import com.spring.bo.CandidateBO;
//import com.spring.config.ApplicationConfig;
//import com.spring.exception.InvalidPhoneNumberException;
//import com.spring.model.Candidate;
//
//public class CandidateService 
//{
//	//Fill your code here
//
//}

package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.spring.bo.CustomerBO;
import com.spring.config.ApplicationConfig;
import com.spring.exception.InvalidPhoneNumberException;
import com.spring.model.Customer;

 @Component
public class CustomerService 
{
	@Autowired
	private CustomerBO customerBoObj;

	
	public CustomerBO getCustomerBoObj() {
		return customerBoObj;
	}

	public void setCustomerBoObj(CustomerBO customerBoObj) {	 	  	    	    		        	 	
		this.customerBoObj = customerBoObj;
	}


	public double calculateTotalBillAmount (String customerName,String mailId,String customerType,String phoneNumber,String comboType) throws InvalidPhoneNumberException
	{
		double amount=0.0;
		if(phoneNumber.matches("[0-9]+") && phoneNumber.length() == 10)
		{
			ApplicationContext ctx=new AnnotationConfigApplicationContext(ApplicationConfig.class);
			Customer cObj=(Customer)ctx.getBean("customer");
			cObj.setCustomerName(customerName);
			cObj.setMailId(mailId);
			cObj.setCustomerType(customerType);
			cObj.setPhoneNumber(phoneNumber);
			cObj.setComboType(comboType);
			
			amount=customerBoObj.calculateTotalBillAmount(cObj);
			return amount;
		}
		else
		{
			throw new InvalidPhoneNumberException("Invalid Phone Number");
		}
	}
}
	 	  	    	    		        	 	
