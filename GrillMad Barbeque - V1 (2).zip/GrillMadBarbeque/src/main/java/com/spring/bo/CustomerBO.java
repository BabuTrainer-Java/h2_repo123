package com.spring.bo;

import org.springframework.stereotype.Component;

import com.spring.model.Customer;

@Component
public class CustomerBO 
{
	
	public double calculateTotalBillAmount (Customer cObj)
	{
		double amount=0.0,temp;
		if(cObj.getCustomerType().equalsIgnoreCase("Prime") && cObj.getPrice().getPriceDetails().containsKey(cObj.getComboType()))
		{
			temp = cObj.getPrice().getPriceDetails().get(cObj.getComboType()).doubleValue();
			amount = temp - (temp * 12)/100.0;
		}
		else if(cObj.getCustomerType().equalsIgnoreCase("Regular") && cObj.getPrice().getPriceDetails().containsKey(cObj.getComboType()))
		{
			temp = cObj.getPrice().getPriceDetails().get(cObj.getComboType()).doubleValue();
			amount = temp - (temp * 6)/100.0;
		}
		else
		{
			amount = cObj.getPrice().getPriceDetails().get(cObj.getComboType()).doubleValue();
		}
		return amount;
	}

}

//package com.spring.bo;
//
//import com.spring.model.Candidate;
//
//public class CandidateBO 
//{	 	  	    	    		        	 	
//	
//	//Fill your code here
//
//}
