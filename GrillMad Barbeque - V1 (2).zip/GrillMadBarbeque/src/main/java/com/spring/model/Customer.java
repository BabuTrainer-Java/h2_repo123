
//package com.spring.model;
//
//public class Candidate 
//{
//	//Fill your code here	
//}

package com.spring.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Customer 
{
	private String customerName;
	private String mailId;
	private String customerType;
	private String phoneNumber;
	private String comboType;
	@Autowired
	private PriceInfo price;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getCustomerType() {
		return customerType;
	}	 	  	    	    		        	 	
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getComboType() {
		return comboType;
	}
	public void setComboType(String comboType) {
		this.comboType = comboType;
	}
	public PriceInfo getPrice() {
		return price;
	}
	public void setPrice(PriceInfo price) {
		this.price = price;
	}
	
	
	
	
}
	 	  	    	    		        	 	
