//package com.spring.model;
//
//import java.util.*;
//
//
//public class FeesInfo 
//{
//	//Fill your code here
//}

package com.spring.model;

import java.util.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class PriceInfo 
{
    @Value("#{${comboPrice.map}}")
	private Map<String,Double> priceDetails;

	public Map<String, Double> getPriceDetails() {
		return priceDetails;
	}

	public void setPriceDetails(Map<String, Double> priceDetails) {
		this.priceDetails = priceDetails;
	}

	
}
	 	  	    	    		        	 	
