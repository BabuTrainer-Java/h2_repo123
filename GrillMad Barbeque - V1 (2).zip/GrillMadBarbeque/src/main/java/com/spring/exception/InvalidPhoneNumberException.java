package com.spring.exception;

public class InvalidPhoneNumberException extends Exception
{
	public InvalidPhoneNumberException(String msg)
	{
		System.out.println(msg);
	}

}

//package com.spring.exception;
//
//public class InvalidPhoneNumberException extends Exception
//{
//	public InvalidPhoneNumberException(String msg)
//	{
//		//Fill your code here
//
//	}
//
//}
