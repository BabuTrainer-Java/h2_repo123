package com.spring.main;


import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.config.ApplicationConfig;
import com.spring.exception.InvalidPhoneNumberException;
import com.spring.service.CustomerService;

public class Driver {

	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		
		double amount;
		String customerName,mailId,customerType,phoneNumber,comboType;
		System.out.println("Enter Customer Name:");
		customerName=in.nextLine();
		System.out.println("Enter Customer MailId:");
		mailId=in.nextLine();
		System.out.println("Enter CustomerType (Prime/Regular):");
		customerType=in.nextLine();
		System.out.println("Enter Customer 10 digit Mobile Number:");
		phoneNumber=in.nextLine();
		System.out.println("Enter Customer comboType (Combo-I/Combo-II/Combo-III):");
		comboType=in.nextLine();
		
// 		ApplicationContext ctx1=new ClassPathXmlApplicationContext("beans.xml");
		ApplicationContext ctx=new AnnotationConfigApplicationContext(ApplicationConfig.class);
		CustomerService customerObj=(CustomerService)ctx.getBean("customerService");
		try
		{	 	  	    	    		        	 	
			amount=customerObj.calculateTotalBillAmount(customerName, mailId, customerType, phoneNumber, comboType);
			
			
			System.out.println("Total Bill Amount to be paidISRs:"+amount);
// 			System.out.println("Thank You in "+loc+" - "+message);
		}
		catch(InvalidPhoneNumberException str)
		{
			//System.out.println(str);
			str.printStackTrace();
		}

	}

}

//package com.spring.main;
//
//import java.util.*;
//
//import com.spring.config.ApplicationConfig;
//import com.spring.exception.InvalidPhoneNumberException;
//import com.spring.service.CandidateService;
//
//public class Driver {
//
//	public static void main(String[] args)
//	{
//		//Fill your code here
//
//	}
//
//}

	 	  	    	    		        	 	
