package com.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.entities.Course;
import com.exception.InvalidCourseException;
import com.repository.CourseRepository;

@Component
public class CourseDAOImpl implements ICourseDAO {

    @Autowired
    private CourseRepository courseRepository;

    public Course addCourse(Course course) {
        return courseRepository.save(course);
    }

    public Course viewCourseById(int courseId) throws InvalidCourseException {
        Course course = courseRepository.findById(courseId).orElse(null);
        if (course == null) {
            throw new InvalidCourseException("Course not found");
        }
        return course;
    }

    public List<Course> viewCoursesByCategory(String category) {
        return courseRepository.findByCategory(category);
    }

    public List<Course> viewCoursesByFee(double lowerLimit, double upperLimit) {
        return courseRepository.findByFeeBetween(lowerLimit, upperLimit);
    }

    public List<Course> viewCoursesByUniversityAndCourseDuration(String university, int courseDuration) {
        return courseRepository.findByUniversityAndCourseDuration(university, courseDuration);
    }
}

