package com.dao;

import java.util.List; 
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.entities.Assessment;
import com.entities.Course;
import com.exception.InvalidCourseException;
import com.exception.InvalidAssessmentException;
import com.repository.CourseRepository;
import com.repository.AssessmentRepository;

@Component
public class AssessmentDAOImpl implements IAssessmentDAO {

    @Autowired
    private AssessmentRepository assessmentRepository;

    @Autowired
    private CourseRepository courseRepository;

    public Assessment addAssessment(Assessment assessment, int courseId) throws InvalidCourseException {
        Course course = courseRepository.findById(courseId).orElse(null);
        if (course == null) {
            throw new InvalidCourseException("Course not found");
        }
        assessment.setCourseObj(course);
        assessmentRepository.save(assessment);
        return assessment;
    }

    public Assessment updateAttempts(int assessmentId, int attempts) throws InvalidAssessmentException {
        Assessment assessment = assessmentRepository.findById(assessmentId).orElse(null);
        if (assessment == null) {
            throw new InvalidAssessmentException("Assessment not found");
        }
        assessment.setAttempts(attempts);
        return assessmentRepository.save(assessment);
    }

    public List<Assessment> viewAssessmentsByAssessmentType(String assessmentType) {
        return assessmentRepository.findByAssessmentType(assessmentType);
    }

    public List<Assessment> viewAssessmentsByCourseName(String courseName) {
        return assessmentRepository.findByCourseObj_CourseName(courseName);
    }

    public Assessment deleteAssessment(int assessmentId) throws InvalidAssessmentException {
        Optional<Assessment> obj = assessmentRepository.findById(assessmentId);
        if (obj.isPresent()) {
            assessmentRepository.delete(obj.get());
            return obj.get();
        } else {
            throw new InvalidAssessmentException("Assessment not found");
        }
    }
}
