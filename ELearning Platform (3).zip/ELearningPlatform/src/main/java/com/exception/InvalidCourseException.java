package com.exception;

public class InvalidCourseException extends Exception {
    
    public InvalidCourseException() {
        super();
    }

    public InvalidCourseException(String message) {
        super(message);
    }
}
