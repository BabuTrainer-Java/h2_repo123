package com.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.entities.Course;

@Repository
public interface CourseRepository extends JpaRepository<Course, Integer> {

    public List<Course> findByCategory(String category);
    public List<Course> findByFeeBetween(double lowerLimit, double upperLimit);
    public List<Course> findByUniversityAndCourseDuration(String university, int courseDuration);

}