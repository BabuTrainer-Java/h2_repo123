package com.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.entities.Assessment;

@Repository
public interface AssessmentRepository extends JpaRepository<Assessment, Integer> {

    public List<Assessment> findByAssessmentType(String assessmentType);
    public List<Assessment> findByCourseObj_CourseName(String courseName);
}
