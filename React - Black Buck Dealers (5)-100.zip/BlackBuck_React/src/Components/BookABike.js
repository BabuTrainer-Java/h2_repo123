import React, { Component } from 'react';

const styles = { 
table: {        backgroundColor: '#8fbc8f',        marginLeft: 'auto',        marginRight: 'auto',        marginTop: '50px'    }, 
h1: {        textAlign: 'center',        color: '#b22222'    }, 
form: {        backgroundColor: '#ffe4c4',        borderStyle: 'dotted'    }};

class BookABike extends Component {   
constructor(props) {      
super(props);     
this.state = { name: '', display: '', brand: '', colour: '', expdt: '', lid: '', mail: '', mobile: '' }; 

    
}   

handleChange = (event) => {  
this.setState({ name: event.target.value }); 
} 
brandchangeHandler = (event) => {   
this.setState({ brand: event.target.value });  
}   
colourchangeHandler = (event) => {  
this.setState({ colour: event.target.value });  
}

datehandler = (event) => {    
this.setState({ expdt: event.target.value });   
} 

LicIdhandler = (event) => {  
this.setState({ lid: event.target.value });  
}  
handleMailChange = (event) => {  
this.setState({ mail: event.target.value }); 
}  
handleMobileChange = (event) => {  
this.setState({ mobile: event.target.value }); 
} 
handleSubmit = (event) => {     
if (this.state.name === "" || this.state.mail === "" || this.state.mobile === "" || this.state.lid === "" || this.state.expdt === "" || this.state.brand === "" || this.state.colour === "") { 
this.setState({
display: 'Please fill all the required fields' });    
}
else {  
   var l = this.state.lid;    
   if (l.length >= 9 && l.length <= 13) {     
   var date = new Date();     
   var exp = this.state.expdt;     
   var expdt = new Date(exp);      
   if (expdt.getTime() > date.getTime()) {   
   var result = new Date(date);              
   result.setDate(result.getDate() + 20);    
   var resdt = result.getDate() + '-' + (result.getMonth() + 1) + '-' + result.getFullYear(); 
   
   this.setState({
   display: 'Hai ' + this.state.name + '. Your Registration for ' + this.state.brand + ' is successful. Tentative Delivery Date will be on ' + resdt });  
   
       
   } else {  
   
   this.setState({ display: 'Hai ' + this.state.name + '!!!.Check your License Validity and register again' });   
   }
   }
   else {  
   this.setState({ display: 'Check your License Number and register again' });  
   }
   }
   }
   render() {       
   return (         
   <div>        
   <form style={styles.form}>   
   <h1 style={styles.h1}>Bon Voyage!!</h1>  
   
   <table style={styles.table}>
   
   <tr>
   <td colspan="2">Name:</td>
   <td colspan="2"><input type="text" id="name" placeholder="Enter your Name" onChange={this.handleChange} /></td></tr>
   <tr><td colspan="2">Email Id:</td> 
   <td colspan="2"><input type="email" id="email" placeholder='Enter your Email' onChange={this.handleMailChange} /></td></tr> 
   <tr><td colspan="2">Mobile Number:</td>      
   <td colspan="2"><input type="tel" id="mobile" placeholder='Enter your mobile number' onChange={this.handleMobileChange} /></td></tr> 
   <tr><td colspan="2">License Id:</td> 
   <td colspan="2"><input type="text" id="Lid" placeholder='Enter your License ID' onChange={this.LicIdhandler} /></td></tr>    
   <tr><td colspan="2">License Expiry Date:</td>    
   <td colspan="2"><input type="date" id="Ldate" placeholder='Enter your License Expiry Date' onChange={this.datehandler} /></td></tr> 
   <tr><td colspan="2">Brand selection:</td>
   <td><select id="brand" onChange={this.brandchangeHandler}> 
   <option value="Select the Brand">Select Brand</option>   
   <option value="Hawk">Odysse hawk</option>            
   <option value="Benling">Benling Aura</option>                
   <option value="ipraise">Okiawa i-Praise</option>         
   
<option value="Hero">Hero Electric Nyx</option>              
<option value="Revolt">Revolt RV</option>                    
</select></td></tr>            
<tr><td colspan="2">Choose colour:</td>         
<td colspan="2"><select id="colour" onChange={this.colourchangeHandler}>     
<option value="Select Colour">Select the colour</option>                
<option value="Red">Rebel Red</option>                   
<option value="Grey">Mist Grey</option>                  
<option value="Black">Cosmic Black</option>     
</select>
</td>
</tr>
</table>

<div id="submitStyle" style={{textAlign:'center', marginTop:'auto', paddingTop:'75px'}}>
<button id="submit" type="submit" name="Submit" onClick={this.handleSubmit}>Submit</button>
</div>
</form>
</div>

);

}}

export default BookABike;

