import React, { Component } from 'react';

const styles = {  
    h1: {        color: '#b22222',        textAlign: 'center'    }, 
    h2: {        color: '#b22222'    },    p: {        fontSize: 'large',        color: '#dc143c'    },  
    div: {        backgroundColor: '#ffe4c4',        borderStyle: 'dotted',        color: '#4c684c'    }};
    
    var data = [    { "Bikename": "Benling Aura", "Cost": "$500", "BatteryChargeTime": "3.5 hours", "speed": "15 mph" }, 
    { "Bikename": "Okiawa i-Praise", "Cost": "$1000", "BatteryChargeTime": "5 hours", "speed": "20 mph" },   
    { "Bikename": "Hero Electric Nyx", "Cost": "$1500", "BatteryChargeTime": "7 hours", "speed": "25 mph" }, 
    { "Bikename": "Revolt RV", "Cost": "$1800", "BatteryChargeTime": "8 hours", "speed": "30 mph" }];
    
    class Info extends Component { 
        render() {    
            return (   
                <div style={styles.div}>    
                <h1 style={styles.h1}>Its Great to see you in future!!!</h1>     
                <h2 style={styles.h2}>Please find the details below</h2>      
                {data.map(item => (       
                    <dl key={item.Bikename}>   
                    <dt>Bike Name: {item.Bikename}</dt>       
                    <dd>Cost: {item.Cost}</dd>              
                    <dd>Battery Charge Time: {item.BatteryChargeTime}</dd>           
                    <dd>Speed: {item.speed}</dd>        
                    </dl>         
                    ))}     
                    <p style={styles.p}>   
                    **All payment related information and other important updates will be shared on those contact details only.
                    <br /><br />     
                    **The price of motorcycle shall be applicable as prevailing on the date of delivery of motorcycle to customer.   
                    </p>  
                    </div>     
                    );  
                    

        }}
        
        export default Info;