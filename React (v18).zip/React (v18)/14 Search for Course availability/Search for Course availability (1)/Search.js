import React, { Component } from 'react';
import './styles.css';
import courseList from './courseList.json';


class Search extends Component {
    state={
		course : null,
		name  : null,
	submitStatus : false
  	  }
	  searchCourse=(event)=>{
		//event.preventDefault();
			  let inputCourse= event.target.value;
		let found=false;
		for(var course of  courseList){
			//console.log(course+" "+inputCourse);
		  if(course.toLowerCase()===inputCourse.toLowerCase()){
			 found=true;
			  this.setState({
		  course:inputCourse
		})
		}
		}
		if(!found){
		  this.setState({
		  course: "course '"+inputCourse+"' is currently not available"
		})
	  }
	  else if(found){
		this.setState({
			course: "course '"+inputCourse+"' is currently available"
		})
	  }
	  }
     displayName=(event)=>{
		this.setState({name:event.target.value})
	 }
   
  handleSubmit=(event)=>{
	event.preventDefault();
	//this.state.submitStatus=true;
	this.setState({submitStatus:true});
  }
	  render(){
		  return (
			<form>
			<div>
			 <h2>EXCEL COACHING CENTER</h2>
			<label>Name</label><br></br>
			<input id="name" type="text" onChange={this.displayName}></input><br></br><br></br>
			<label>Qualification</label><br></br>
			<select>
				<option>BE/BTech</option>
				<option>ME/MTech</option>
				<option>BCA/MCA</option>
			</select>
			<br></br><br></br>
			<label>Search by Course</label><br></br>
			<input id="search" type="text" onChange={this.searchCourse} /><br></br><br></br>
            <button onClick={this.handleSubmit}>Submit</button> <br></br>
			<>{this.state.name!=null && this.state.course!=null && this.state.submitStatus===true &&
			    <>
				<Display name={this.state.name} course={this.state.course}/>
				</>
				}
			</>
              
			</div>
			</form>
		  )
		}
}
class Display extends Component {
    render(){
			//console.log("submitt"+this.props.submitStatus);
			 return(
				<>
				<br></br>
				<div>Welcome to Excel coaching centre!!! <br></br> Hi {this.props.name}, {this.props.course}</div>
				 </>
			 )		
	  }
}

export {Display}
export default Search;