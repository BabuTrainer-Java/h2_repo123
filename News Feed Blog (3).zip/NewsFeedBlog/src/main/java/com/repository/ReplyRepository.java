package com.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.entities.Reply;
import org.springframework.data.repository.CrudRepository;

//Provide necessary annotation
@Repository
public interface ReplyRepository extends JpaRepository<Reply, Integer> {

	// Provide necessary methods to view replies by user and view replies by based on article title
    public List<Reply> findByUser(String user);
    public List<Reply> findByArticleObjArticleTitle(String articleTitle);
}
