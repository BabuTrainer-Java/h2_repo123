package com.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.entities.Article;
//Provide necessary annotation
@Repository
public interface ArticleRepository extends JpaRepository<Article, Integer> {

	// Provide necessary methods to view articles by tag,
	//view articles with likes greater than or equal to the given value
	//and to view articles by author and article type
	public List<Article> findByTag(String tag);
	public List<Article> findByLikesCountGreaterThanEqual(int likesCount);
	public List<Article> findByAuthorAndArticleType(String author,String articleType);

}
