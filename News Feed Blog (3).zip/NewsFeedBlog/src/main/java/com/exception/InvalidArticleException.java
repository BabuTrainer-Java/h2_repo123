package com.exception;

public class InvalidArticleException extends Exception {
    
    
}
