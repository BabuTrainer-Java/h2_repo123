package com.exception;

public class InvalidReplyException extends Exception  {
    
    
}
