package com.service;

import java.util.List;
import com.entities.Article;
import com.exception.InvalidArticleException;

public interface IArticleService {

	public Article addArticle(Article article);

	public Article viewArticleById(int articleId) throws InvalidArticleException;

	public List<Article> viewArticlesByTag(String tag);

	public List<Article> viewArticlesByLikesCount(int likesCount);

	public List<Article> viewArticlesByAuthorAndArticleType(String author, String articleType);
}
