package com.service;
import org.springframework.stereotype.Service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import com.dao.IArticleDAO;
import com.entities.Article;
import com.exception.InvalidArticleException;

//Provide necessary annotation
@Service
public class ArticleServiceImpl implements IArticleService {

	// Provide necessary annotation
	@Autowired
	private IArticleDAO articleDAO;

	public Article addArticle(Article article) {
		return articleDAO.addArticle(article);
	}

	public Article viewArticleById(int articleId) throws InvalidArticleException {
		return articleDAO.viewArticleById(articleId);
	}

	public List<Article> viewArticlesByTag(String tag) {
		return articleDAO.viewArticlesByTag(tag);
	}

	public List<Article> viewArticlesByLikesCount(int likesCount) {
		return articleDAO.viewArticlesByLikesCount(likesCount);
	}

	public List<Article> viewArticlesByAuthorAndArticleType(String author, String articleType) {
		return articleDAO.viewArticlesByAuthorAndArticleType(author,articleType);
	}

}
