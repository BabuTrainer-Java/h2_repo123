package com.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.entities.Article;
import com.exception.InvalidArticleException;
import com.repository.ArticleRepository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import com.entities.Reply;

@Component
public class ArticleDAOImpl implements IArticleDAO {

	// Provide necessary Annotation
	@Autowired
	private ArticleRepository articleRepository;

	public Article addArticle(Article article) {
		// fill code

		return articleRepository.save(article);
	}

	public Article viewArticleById(int articleId) throws InvalidArticleException {

		// fill code
        Article article=articleRepository.findById(articleId).orElse(null);
        if(article == null) {throw new InvalidArticleException();
            
        }
		return article;

	}

	public List<Article> viewArticlesByTag(String tag) {
	    return articleRepository.findByTag(tag);
		// fill code
		
	}

	public List<Article> viewArticlesByLikesCount(int likesCount) {
	    return articleRepository.findByLikesCountGreaterThanEqual(likesCount);
		// fill code
	//	return null;

	}

	public List<Article> viewArticlesByAuthorAndArticleType(String author, String articleType) {
	    

		return articleRepository.findByAuthorAndArticleType(author,articleType);
	}
}
