package com.dao;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.entities.Reply;
import com.entities.Article;
import com.exception.InvalidArticleException;
import com.exception.InvalidReplyException;
import com.repository.ArticleRepository;
import com.repository.ReplyRepository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
@Component
public class ReplyDAOImpl implements IReplyDAO {

	// Provide necessary Annotation
	@Autowired
	private ReplyRepository replyRepository;

	// Provide necessary Annotation
	@Autowired
	private ArticleRepository articleRepository;

	public Reply addReply(Reply reply, int articleId) throws InvalidArticleException {

		// fill code
		Article article=articleRepository.findById(articleId).orElse(null);
        if(article == null) {throw new InvalidArticleException();
            
        }
		reply.setArticleObj(article);
		return replyRepository.save(reply);
	}

	public Reply updateVisibility(int replyId, String visibility) throws InvalidReplyException {
		// fill code
		Reply reply=replyRepository.findById(replyId).orElse(null);
        if(reply == null) {
            throw new InvalidReplyException();
            
        }
		reply.setVisibility(visibility);
		return replyRepository.save(reply);
		//return null;

	}

	public List<Reply> viewRepliesByUser(String user) {

		// fill code

		return replyRepository.findByUser(user);
	}

	public List<Reply> viewRepliesByArticleTitle(String articleTitle) {

		// fill code

		return replyRepository.findByArticleObjArticleTitle(articleTitle);
	}

	public Reply deleteReply(int replyId) throws InvalidReplyException {
	    Optional<Reply>obj=replyRepository.findById(replyId);
	    if(obj.isPresent())
	    {
	        replyRepository.delete(obj.get());
	        return obj.get();
	        
	    }else{ 
	            throw new InvalidReplyException();
	    }
		// fill code


	}

}
