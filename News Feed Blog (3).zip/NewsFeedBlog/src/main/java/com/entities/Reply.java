package com.entities;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
//Provide necessary Annotation
@Entity
public class Reply {

	// Provide necessary Annotation
    @Id
	private int replyId;
	private String user;
	private String replyContent;
	private String replyType;
	private String visibility;
	// Provide necessary Annotations
	@ManyToOne
	@JoinColumn(name="article_id")
	@JsonIgnoreProperties
	private Article articleObj;

	public Reply() {
		super();
	}

	public Reply(int replyId, String user, String replyContent, String replyType, String visibility,
			Article articleObj) {
		super();
		this.replyId = replyId;
		this.user = user;
		this.replyContent = replyContent;
		this.replyType = replyType;
		this.visibility = visibility;
		this.articleObj = articleObj;
	}

	public int getReplyId() {
		return replyId;
	}

	public void setReplyId(int replyId) {
		this.replyId = replyId;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getReplyContent() {
		return replyContent;
	}

	public void setReplyContent(String replyContent) {
		this.replyContent = replyContent;
	}

	public String getReplyType() {
		return replyType;
	}

	public void setReplyType(String replyType) {
		this.replyType = replyType;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public Article getArticleObj() {
		return articleObj;
	}

	public void setArticleObj(Article articleObj) {
		this.articleObj = articleObj;
	}

}
