package com.entities;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Project {

    @Id
    private int projectId;
    private String projectName;
    private String projectDescription;
    private int duration;
    private String location;
    private String clientName;
    private String managerName;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "projectObj")
    @JsonIgnoreProperties
    private List<Bug> bugList;

    public Project() {
        super();
    }

    public Project(int projectId, String projectName, String projectDescription, int duration, String location,
            String clientName, String managerName, List<Bug> bugList) {
        super();
        this.projectId = projectId;
        this.projectName = projectName;
        this.projectDescription = projectDescription;
        this.duration = duration;
        this.location = location;
        this.clientName = clientName;
        this.managerName = managerName;
        this.bugList = bugList;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectDescription() {
        return projectDescription;
    }

    public void setProjectDescription(String projectDescription) {
        this.projectDescription = projectDescription;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    public List<Bug> getBugList() {
        return bugList;
    }

    public void setBugList(List<Bug> bugList) {
        this.bugList = bugList;
    }
}
