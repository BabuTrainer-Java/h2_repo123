package com.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Bug {

    @Id
    private int bugId;
    private String bugType;
    private String bugDescription;
    private String status;
    private int severity;

    @ManyToOne
    @JoinColumn(name = "project_id")
    @JsonIgnoreProperties
    private Project projectObj;

    public Bug() {
        super();
    }

    public Bug(int bugId, String bugType, String bugDescription, String status, int severity, Project projectObj) {
        super();
        this.bugId = bugId;
        this.bugType = bugType;
        this.bugDescription = bugDescription;
        this.status = status;
        this.severity = severity;
        this.projectObj = projectObj;
    }

    public int getBugId() {
        return bugId;
    }

    public void setBugId(int bugId) {
        this.bugId = bugId;
    }

    public String getBugType() {
        return bugType;
    }

    public void setBugType(String bugType) {
        this.bugType = bugType;
    }

    public String getBugDescription() {
        return bugDescription;
    }

    public void setBugDescription(String bugDescription) {
        this.bugDescription = bugDescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getSeverity() {
        return severity;
    }

    public void setSeverity(int severity) {
        this.severity = severity;
    }

    public Project getProjectObj() {
        return projectObj;
    }

    public void setProjectObj(Project projectObj) {
        this.projectObj = projectObj;
    }
}