package com.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dao.IProjectDAO;
import com.entities.Project;
import com.exception.InvalidProjectException;

@Service
public class ProjectServiceImpl implements IProjectService {

    @Autowired
    private IProjectDAO projectDAO;

    @Override
    public Project addProject(Project project) {
        return projectDAO.addProject(project);
    }

    @Override
    public Project viewProjectById(int projectId) throws InvalidProjectException {
        return projectDAO.viewProjectById(projectId);
    }

    @Override
    public List<Project> viewProjectsUnderManagerName(String managerName) {
        return projectDAO.viewProjectsUnderManagerName(managerName);
    }

    @Override
    public List<Project> viewProjectsByDuration(int lowerLimit, int upperLimit) {
        return projectDAO.viewProjectsByDuration(lowerLimit, upperLimit);
    }

    @Override
    public List<Project> viewProjectsByClientNameAndLocation(String clientName, String location) {
        return projectDAO.viewProjectsByClientNameAndLocation(clientName, location);
    }
}