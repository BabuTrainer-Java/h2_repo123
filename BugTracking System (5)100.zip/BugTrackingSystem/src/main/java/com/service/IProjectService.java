package com.service;

import java.util.List;
import com.entities.Project;
import com.exception.InvalidProjectException;

public interface IProjectService {
	
	public Project addProject(Project project);
	public Project viewProjectById(int projectId) throws InvalidProjectException;
	public List<Project> viewProjectsUnderManagerName(String managerName);
	public List<Project> viewProjectsByDuration(int lowerLimit,int upperLimit);
	public List<Project> viewProjectsByClientNameAndLocation(String clientName,String location);
}