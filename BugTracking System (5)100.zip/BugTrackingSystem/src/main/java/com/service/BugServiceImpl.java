package com.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dao.IBugDAO;
import com.entities.Bug;
import com.exception.InvalidProjectException;
import com.exception.InvalidBugException;

@Service
public class BugServiceImpl implements IBugService {

    @Autowired
    private IBugDAO bugDAO;

    @Override
    public Bug addBug(Bug bug, int projectId) throws InvalidProjectException {
        return bugDAO.addBug(bug, projectId);
    }

    @Override
    public Bug updateBugStatus(int bugId, String status) throws InvalidBugException {
        return bugDAO.updateBugStatus(bugId, status);
    }

    @Override
    public List<Bug> viewBugsByBugType(String bugType) {
        return bugDAO.viewBugsByBugType(bugType);
    }

    @Override
    public List<Bug> viewBugsBySeverity(int severity) {
        return bugDAO.viewBugsBySeverity(severity);
    }

    @Override
    public List<Bug> viewBugsByProjectName(String projectName) {
        return bugDAO.viewBugsByProjectName(projectName);
    }
}