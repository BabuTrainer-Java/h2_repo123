package com.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.entities.Project;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Integer> {
    List<Project> findByManagerName(String managerName);
    List<Project> findByDurationBetween(int lowerLimit, int upperLimit);
    List<Project> findByClientNameAndLocation(String clientName, String location);
}