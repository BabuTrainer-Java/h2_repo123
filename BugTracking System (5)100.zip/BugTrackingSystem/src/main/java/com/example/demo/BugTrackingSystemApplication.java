
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.boot.CommandLineRunner;

@EntityScan("com.entities")
@ComponentScan(basePackages = { "com.repository", "com.dao", "com.entities", "com.service", "com.exception" })
@EnableJpaRepositories("com.repository")
@SpringBootApplication
public class BugTrackingSystemApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(BugTrackingSystemApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Invoke the methods");
    }
}