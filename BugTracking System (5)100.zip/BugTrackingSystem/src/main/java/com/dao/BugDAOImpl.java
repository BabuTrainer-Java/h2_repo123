package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.entities.Bug;
import com.entities.Project;
import com.exception.InvalidProjectException;
import com.exception.InvalidBugException;
import com.repository.ProjectRepository;
import com.repository.BugRepository;

@Component
public class BugDAOImpl implements IBugDAO {

    @Autowired
    private BugRepository bugRepository;

    @Autowired
    private ProjectRepository projectRepository;

    @Override
    public Bug addBug(Bug bug, int projectId) throws InvalidProjectException {
        Project project = projectRepository.findById(projectId).orElse(null);
        if (project == null) {
            throw new InvalidProjectException("Project not found");
        }
        bug.setProjectObj(project);
        bugRepository.save(bug);
        return bug;
    }

    @Override
    public Bug updateBugStatus(int bugId, String status) throws InvalidBugException {
        Bug bug = bugRepository.findById(bugId).orElse(null);
        if (bug == null) {
            throw new InvalidBugException("Bug not found");
        }
        bug.setStatus(status);
        return bugRepository.save(bug);
    }

    @Override
    public List<Bug> viewBugsByBugType(String bugType) {
        return bugRepository.findByBugType(bugType);
    }

    @Override
    public List<Bug> viewBugsByProjectName(String projectName) {
        return bugRepository.findByProjectObj_ProjectName(projectName);
    }

    @Override
    public List<Bug> viewBugsBySeverity(int severity) {
        return bugRepository.findBySeverity(severity);
    }
}
