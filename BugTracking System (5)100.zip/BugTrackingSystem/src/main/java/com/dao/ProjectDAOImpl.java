package com.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.entities.Project;
import com.exception.InvalidProjectException;
import com.repository.ProjectRepository;

@Component
public class ProjectDAOImpl implements IProjectDAO {

    @Autowired
    private ProjectRepository projectRepository;

    @Override
    public Project addProject(Project project) {
        return projectRepository.save(project);
    }

    @Override
    public Project viewProjectById(int projectId) throws InvalidProjectException {
        return projectRepository.findById(projectId).orElseThrow(() -> new InvalidProjectException("Project not found"));
    }

    @Override
    public List<Project> viewProjectsUnderManagerName(String managerName) {
        return projectRepository.findByManagerName(managerName);
    }

    @Override
    public List<Project> viewProjectsByDuration(int lowerLimit, int upperLimit) {
        return projectRepository.findByDurationBetween(lowerLimit, upperLimit);
    }

    @Override
    public List<Project> viewProjectsByClientNameAndLocation(String clientName, String location) {
        return projectRepository.findByClientNameAndLocation(clientName, location);
    }
}