package com.dao;

import java.util.List;

import com.entities.Bug;
import com.exception.InvalidProjectException;
import com.exception.InvalidBugException;

public interface IBugDAO {
	public Bug addBug(Bug bug,int projectId) throws InvalidProjectException;
	public Bug updateBugStatus(int bugId,String status) throws InvalidBugException;
	public List<Bug> viewBugsByBugType(String bugType);
	public List<Bug> viewBugsBySeverity(int severity);
	public List<Bug>  viewBugsByProjectName(String projectName);
}