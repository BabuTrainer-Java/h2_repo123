package com.exception;

public class InvalidBugException extends Exception {
    public InvalidBugException() {
        super();
    }

    public InvalidBugException(String message) {
        super(message);
    }
}