package com.exception;

public class InvalidProjectException extends Exception {
    public InvalidProjectException() {
        super();
    }

    public InvalidProjectException(String message) {
        super(message);
    }
}