package com.shipwreckstore.proxy;

import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.RequestMapping;


@FeignClient(name="ShipwreckStoreGreeting")
public interface ServiceProxy {
    @RequestMapping("/welcome")	
	   public String greeting();
}
