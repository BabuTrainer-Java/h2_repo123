package com.shipwreckstore.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingController {

	
	@GetMapping(value="/welcome")
	public @ResponseBody String greeting( ) {
		
		return "Welcome to Shipwreck store. It is a store that specializes in equipment or supplies related to scuba diving or marine salvage, which are often used in the exploration and recovery of shipwrecks.Spread over an area of 2,600 sq ft.";
		
	}
}

