package com.shipwreckstore.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages= {"com.shipwreckstore.controller"})
public class ShipwreckStoreGreetingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShipwreckStoreGreetingApplication.class, args);
	}

}
