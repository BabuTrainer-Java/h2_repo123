package com.shipwreckstore.model;

import java.time.LocalDate;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;
import org.hibernate.validator.constraints.NotBlank;

import lombok.*;

@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
public class Ship {
	
	@NotEmpty(message="required valid ship id")
	private String shipID;
	@NotEmpty(message="required ship name")
	private String shipName; 
	@NotEmpty(message="required description")
	private String description;
	@NotEmpty(message="required condition")
	private String condition;
	@Min(value=0,message="depth should not be negative")
	private Integer depth;
	@NotNull(message="latitude should not be null")
	private Double latitude;
	@NotNull(message="longitude should not be null")
	private Double longitude;
	@NotNull(message="YearDiscovered should not be null")
	private LocalDate yearDiscovered;
	
	public String getShipID() {
		return shipID;
	}
	

}
