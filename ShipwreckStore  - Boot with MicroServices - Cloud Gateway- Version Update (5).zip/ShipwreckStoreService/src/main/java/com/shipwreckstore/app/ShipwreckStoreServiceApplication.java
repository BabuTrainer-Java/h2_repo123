package com.shipwreckstore.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableDiscoveryClient
@ComponentScan(basePackages={"com.shipwreckstore.model","com.shipwreckstore.controller","com.shipwreckstore.service","com.shipwreckstore.exception","com.shipwreckstore..validation"})
public class ShipwreckStoreServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShipwreckStoreServiceApplication.class, args);
	}

}
