package com.shipwreckstore.controller;

import java.util.List;
import com.shipwreckstore.exception.InvalidShipException;
import com.shipwreckstore.exception.ShipNotAvailableException;
import com.shipwreckstore.model.Ship;
import com.shipwreckstore.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping
public class ShipController {
    
    @Autowired
    private IShipService shipServiceImpl;
	
		@PostMapping(value="/addShip",produces="application/json")
		public Ship addShip(@RequestBody @Validated Ship ship) throws InvalidShipException {	

			return shipServiceImpl.addShip(ship);
		}
	
	@PutMapping(value="/updateDepth/{shipID}/{depth}",produces="application/json")
		public Ship updateDepth(@PathVariable String shipID, @PathVariable int depth) throws ShipNotAvailableException {
		
			  return shipServiceImpl.updateDepth(shipID,depth);
		}
		@GetMapping(value="/getShipWithGoodCondition",produces="application/json")
		public List<Ship> getShipWithGoodCondition()  {
			return shipServiceImpl.getShipWithGoodCondition();
		}
	@GetMapping(value="/getShipWithFairCondition",produces="application/json")
		public List<Ship> getShipWithFairCondition()  {
			return shipServiceImpl.getShipWithFairCondition();
		}
			
	}

