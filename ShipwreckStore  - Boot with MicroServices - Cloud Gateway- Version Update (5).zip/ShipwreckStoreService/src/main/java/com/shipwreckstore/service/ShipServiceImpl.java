package com.shipwreckstore.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.shipwreckstore.exception.*;
import com.shipwreckstore.model.*;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ShipServiceImpl implements IShipService{
	
private static List<Ship> shipList=new ArrayList<Ship>();	  
	
	public static List<Ship> getShipList() {
		return shipList;
	}

	public static void setShipList(List<Ship> shipList) {
		ShipServiceImpl.shipList = shipList;
	}
	
	
	// Implement the service methods as per the requirement	

	public Ship updateDepth( String shipID,int depth)throws ShipNotAvailableException{
		boolean flag = false;
		Ship b1 = null;
		for(Ship b:shipList) {
		    if(b.getShipID().equals(shipID)){
		        b1=b;
		        b.setDepth(depth);
		        flag=true;
		        break;
		    }
		}
		
		if(flag) {
		    log.info("Ship "+shipID+" depth updated successfully to "+depth);
		    return b1;
		}
		else {
		    log.error("Ship with "+shipID+" not available to update the depth");
		    throw new ShipNotAvailableException("Ship with "+shipID+" not available to update the depth");
	    }
	    
	}
	
	public Ship addShip( Ship ship)  throws InvalidShipException{	
		
			if(getShip(ship)==null){
			    shipList.add(ship);
			    log.info("ship with shipID"+ship.getShipID()+" added successfully");
			}
			else {
			    log.error("Ship with "+ship.getShipID()+" already exists!");
			    throw new InvalidShipException("Ship with "+ship.getShipID()+" already exists!");
			}
		return ship;
	}
		
	public Ship getShip(Ship b1) {
	    for(Ship b:shipList) {
	        if(b.getShipID().equals(b1.getShipID())) {
	            return b;
	        }
	    }
	
		return null;
}
	
	public List<Ship> getShipWithGoodCondition()  {
		
		List<Ship> sList = new ArrayList<Ship>();
		for(Ship s:shipList) {
		    if(s.getCondition().equalsIgnoreCase("Good")) {
		        sList.add(s);
		    }
		}
		log.info("Get Ships with good condition is successfully done");
		return sList;
	}
	
	public List<Ship> getShipWithFairCondition()  {
		
		List<Ship> sList = new ArrayList<Ship>();
		for(Ship s:shipList) {
		    if(s.getCondition().equalsIgnoreCase("Fair")) {
		        sList.add(s);
		    }
		}
		log.info("Get Ships with fair condition is successfully done");
		return sList;
	}
	
	
	
	public ShipServiceImpl() {
		populateShips();
	}
	public void populateShips() {
		
		//If needed, you can uncomment the below lines and use the objects to check your application
		
		
//		shipList.add(new Ship("SHIP 1-455","Thistlegorm","British Merchant boat in the red sea","Good",80,34.56,67.75,LocalDate.now().minusYears(28)));
//		shipList.add(new Ship("SHIP 9-789","SS Yongala","A luxury passenger ship wrecked on the great barrier reef","Fair",50,56.78,67.75,LocalDate.now().minusYears(28)));
//		shipList.add(new Ship("SHIP 7-555","Javaship","Programming ship to develop secure applications","Fair",350,80.78,120.75,LocalDate.now().minusYears(31)));
//		shipList.add(new Ship("SHIP 6-458","RMS Titanic","Famous ship for never making her destination","Good",80,70.78,120.75,LocalDate.now().minusYears(110)));
//		shipList.add(new Ship("SHIP 3-623","MS Estonia","British Merchant boat in the Caribbean Sea","Good",280,80.78,90.75,LocalDate.now().minusYears(28)));
//		shipList.add(new Ship("SHIP 5-222","HMS Victory","Now the property of British government under marine laws","Fair",50,60.78,90.75,LocalDate.now().minusYears(14)));
//		shipList.add(new Ship("SHIP 4-345","The Mary Rose","It was a warship in the navy of the Tudor King Henry VIII","Fair",220,80.78,120.75,LocalDate.now().minusYears(40)));

	}

}
