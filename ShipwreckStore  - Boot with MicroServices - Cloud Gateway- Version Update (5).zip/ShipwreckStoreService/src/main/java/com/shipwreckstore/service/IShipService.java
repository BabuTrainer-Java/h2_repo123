package com.shipwreckstore.service;

import java.util.List;

import com.shipwreckstore.exception.*;
import com.shipwreckstore.model.*;

public interface IShipService {
	
	public Ship addShip(Ship ship)  throws InvalidShipException;
	public Ship updateDepth(String shipID,int depth)  throws ShipNotAvailableException;
	public List<Ship> getShipWithGoodCondition() ;
	public List<Ship> getShipWithFairCondition() ;
	
}
