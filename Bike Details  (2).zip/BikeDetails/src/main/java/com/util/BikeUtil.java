package com.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.model.Bike;
import com.exception.InvalidBikeException;

public class BikeUtil {
    List<Bike> bikeList = new ArrayList<>();

    public List<Bike> getBikeList() {
        return bikeList;
    }
    
    public void setBikeList(List<Bike> bikeList) {
        this.bikeList = bikeList;
    }
    
    public boolean validateBrandName(String brandName) throws InvalidBikeException {
    	if(brandName.equalsIgnoreCase("Honda") || brandName.equalsIgnoreCase("Yamaha") ||brandName.equalsIgnoreCase("Suzuki") || brandName.equalsIgnoreCase("Royal Enfield")) {
    		return true;
    	}
    	else {
    		throw new InvalidBikeException("Brand Name is invalid"); 
    	}
    }
    
    
    
    public List<Bike> viewBikeDetailsByBrandName(String brandName) throws InvalidBikeException {
    	List<Bike> result = new ArrayList<>();
    
    	if(bikeList.size()==0) {
    		throw new InvalidBikeException("Bike list is empty");
    	}
    	else {
    		for(Bike bike : bikeList) {
    			if(bike.getBrandName().equalsIgnoreCase(brandName)) {
    				result.add(bike);
    			}
    		}
    		return result;
    	}
    }
   
    
    public Map<Double, Integer> totalCountOfBikesByPriceWise() throws InvalidBikeException {
    	 Map<Double, Integer> result = new LinkedHashMap<>();
        if (bikeList.size() == 0) {
            throw new InvalidBikeException("Bike list is empty");
        } else {
            for (Bike bike : bikeList) {
                double bikePrice = bike.getPrice();

                if (!result.containsKey(bikePrice)) {
                    result.put(bikePrice, 1);
                } else {
                    int temp = result.get(bikePrice);
                    result.put(bikePrice, temp + 1);
                }
            }
            return result;
        }
    }

    
}	 	  	      	  	 	      	      	        	 	