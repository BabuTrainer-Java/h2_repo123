package com.spring.model;

import java.util.Map;

public class RoomChargeInfo 
{
	private Map<String,Float> roomCharges;

	public Map<String, Float> getRoomCharges() {
		return roomCharges;
	}

	public void setRoomCharges(Map<String, Float> roomCharges) {
		this.roomCharges = roomCharges;
	}

	
	
}
