package com.service;

import java.util.ArrayList;
import com.model.ClubMember;

public class MemberService {

    private ArrayList<ClubMember> memberList = new ArrayList<>();

    public ArrayList<ClubMember> getMemberList() {
        return memberList;
    }

    public void setMemberList(ArrayList<ClubMember> memberList) {
        this.memberList = memberList;
    }

    public MemberService() {
        ClubMember memberObj1 = new ClubMember(24, "Paul", "Premium", 75000);
        ClubMember memberObj2 = new ClubMember(20, "Cheenu", "Gold", 50000);
        ClubMember memberObj3 = new ClubMember(79, "Robert", "Premium", 75000);
        ClubMember memberObj4 = new ClubMember(15, "Nawab", "Gold", 50000);
        ClubMember memberObj5 = new ClubMember(99, "Gautam", "Platinum", 90000);
        ClubMember memberObj6 = new ClubMember(25, "Peter", "Gold", 50000);
        ClubMember memberObj7 = new ClubMember(75, "George", "Premium", 75000);
        ClubMember memberObj8 = new ClubMember(63, "Pinky", "Platinum", 90000);
        ClubMember memberObj9 = new ClubMember(71, "Dravid", "Premium", 75000);
        ClubMember memberObj10 = new ClubMember(91, "Ashwin", "Platinum", 90000);

        memberList.add(memberObj1);
        memberList.add(memberObj2);
        memberList.add(memberObj3);
        memberList.add(memberObj4);
        memberList.add(memberObj5);
        memberList.add(memberObj6);
        memberList.add(memberObj7);
        memberList.add(memberObj8);
        memberList.add(memberObj9);
        memberList.add(memberObj10);
    }

    public boolean addMember(ClubMember memberObj) {
        return memberList.add(memberObj);
    }

    public ClubMember viewMemberById(int memberId) {
        ClubMember result = null;
        for (ClubMember member : memberList) {
            if (member.getMemberId() == memberId) {
                result = member;
            }
        }
        return result;
    }

    public ArrayList<ClubMember> viewMemberByType(String memberType) {
        ArrayList<ClubMember> members = new ArrayList<>();
        for (ClubMember member : memberList) {
            if (member.getMemberType().equals(memberType)) {
                members.add(member);
            }
        }
        return members;
    }

    public ArrayList<ClubMember> updateMembershipFees(String memberType, double membershipFees) {
        ArrayList<ClubMember> members = new ArrayList<>();
        for (ClubMember member : memberList) {
            if (member.getMemberType().equals(memberType)) {
                member.setMembershipFees(membershipFees);
                members.add(member);
            }
        }
        return members;
    }

    public boolean deleteMember(int memberId) {
        return memberList.removeIf(member -> member.getMemberId() == memberId);
    }
}
