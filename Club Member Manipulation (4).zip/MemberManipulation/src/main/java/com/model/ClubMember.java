package com.model;

public class ClubMember {

    private int memberId;
    private String memberName;
    private String memberType;
    private double membershipFees;

    public ClubMember() {
    }

    public ClubMember(int memberId, String memberName, String memberType, double membershipFees) {
        super();
        this.memberId = memberId;
        this.memberName = memberName;
        this.memberType = memberType;
        this.membershipFees = membershipFees;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberType() {
        return memberType;
    }

    public void setMemberType(String memberType) {
        this.memberType = memberType;
    }

    public double getMembershipFees() {
        return membershipFees;
    }

    public void setMembershipFees(double membershipFees) {
        this.membershipFees = membershipFees;
    }
}

