package com.controller;

import java.util.ArrayList;
import com.model.ClubMember;
import com.service.MemberService;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import com.exception.InvalidMemberException;

@RestController
@RequestMapping("/member")
public class MemberController {

    @Autowired
    private MemberService service;

    @PostMapping("/addMember")
    public boolean addMember(@RequestBody ClubMember memberObj) {
        return service.addMember(memberObj);
    }

    @GetMapping("/viewMemberById/{id}")
    public ClubMember viewMemberById(@PathVariable("id") int memberId) {
        if (service.viewMemberById(memberId) == null) {
            throw new InvalidMemberException("Member ID " + memberId + " does not exist");
        }
        return service.viewMemberById(memberId);
    }

    @GetMapping("/viewMemberByType/{type}")
    public ArrayList<ClubMember> viewMemberByType(@PathVariable("type") String memberType) {
        return service.viewMemberByType(memberType);
    }

    @PutMapping("/updateMembershipFees/{type}/{fees}")
    public ArrayList<ClubMember> updateMembershipFees(@PathVariable("type") String memberType, @PathVariable("fees") double membershipFees) {
        return service.updateMembershipFees(memberType, membershipFees);
    }

    @DeleteMapping("/deleteMember/{id}")
    public boolean deleteMember(@PathVariable("id") int memberId) {
        return service.deleteMember(memberId);
    }
}

