
package com.controller;

import java.util.ArrayList;

import com.model.PropertyInfo;
import com.service.PropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import com.exception.PropertyInvalidException;
@RestController
@RequestMapping("/HRE")
public class PropertyController {
    @Autowired
	private PropertyService propertyService;
    
    @PostMapping("/insertProperty")
	public boolean addProperty(@RequestBody PropertyInfo propertyObj)
	{
		return propertyService.addProperty(propertyObj);
	}
	
	@GetMapping("/viewPropertyById/{id}")
	public PropertyInfo viewPropertyById(@PathVariable("id")Integer propertyId) {
	    PropertyInfo propertyInfo = propertyService.viewPropertyById(propertyId);
	    if(propertyInfo==null){
	        throw new PropertyInvalidException("Property ID "+propertyId+" does not exist");
	    }
	   return propertyInfo;
	}
    
    @GetMapping("/viewPropertyByLocationAndCostRange/{location}/{lowLimit}/{highLimit}")
	public ArrayList<PropertyInfo> viewPropertyByLocationAndCostRange(@PathVariable String location,@PathVariable double lowLimit,@PathVariable double highLimit)
	{
		return propertyService.viewPropertyByLocationAndCostRange(location,lowLimit,highLimit);
	}
	@PutMapping("/updatePropertyStatus/{id}")
	public boolean updatePropertyStatus(@PathVariable("id") Integer propertyId)
	{
		return propertyService.updatePropertyStatus(propertyId);
	}
	@DeleteMapping("/deleteProperty/{id}")
	public boolean deleteProperty(@PathVariable("id")Integer propertyId) 
	{
		return propertyService.deleteProperty(propertyId);
	}

}

