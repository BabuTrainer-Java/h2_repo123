package com.test;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.exception.InvalidCarBookingException;
import com.model.*;
import com.util.*;
public class BookingUtilTest {

	    private static DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	    private static List<CarBooking> carBookings;
	    private static BookingUtil bookingUtil;

	    @BeforeAll
	    public static void setUp() throws ParseException {
	        CarBooking[] carBookingArray = new CarBooking[8];

	        carBookingArray[0] = new CarBooking("MAR123", "John", "9876543210", "Maruti", "Swift", df.parse("14/12/2023"), 550000.0);
	        carBookingArray[1] = new CarBooking("MAH456", "Smith", "9784567890", "Mahindra", "Bolero", df.parse("30/12/2023"), 750000.0);
	        carBookingArray[2] = new CarBooking("HYU789", "Johnson", "8765432109", "Hyundai", "Venue", df.parse("03/01/2024"), 600000.0);
	        carBookingArray[3] = new CarBooking("TOY101", "Williams", "9870123456", "Toyota", "Innova", df.parse("22/12/2023"), 2500000.0);
	        carBookingArray[4] = new CarBooking("MAR202", "Charlie", "7654321098", "Maruti", "Baleno", df.parse("11/11/2024"), 950000.0);
	        carBookingArray[5] = new CarBooking("MAH303", "David", "8765098765", "Mahindra", "Thar", df.parse("22/12/2024"), 1200000.0);
	        carBookingArray[6] = new CarBooking("TOY505", "Frank", "7890123456", "Toyota", "Glanza", df.parse("22/12/2024"), 780000.0);
	        carBookingArray[7] = new CarBooking("HYU606", "Miller", "8765436789", "Hyundai", "Exter", df.parse("21/09/2023"), 900000.0);

	        carBookings = new ArrayList<>(Arrays.asList(carBookingArray));
	        bookingUtil = new BookingUtil();
	        bookingUtil.setCarBookingList(carBookings);
	    }	 	  	      	  	 	      	      	        	 	
	    
	    @Test
	    public void test11_ValidateCarModelForBrandMaruti() {
	    	boolean flag=false;
	    	String[] str= {"Swift","Baleno"};
			try {
				flag = bookingUtil.validateCarModel(str);
			} catch (InvalidCarBookingException e) {}
			assertTrue(flag);

	    }
	    
	    @Test
	    public void test12_ValidateCarModelForBrandMahindra() {
	    	boolean flag=false;
	    	String[] str= {"Bolero","Thar"};
			try {
				flag = bookingUtil.validateCarModel(str);
			} catch (InvalidCarBookingException e) {}
			assertTrue(flag);
	    }	 	  	      	  	 	      	      	        	 	
	    @Test
	    public void test13_ValidateCarModelForBrandToyota() {
	    	boolean flag=false;
	    	String[] str= {"Innova","Glanza"};
			try {
				flag = bookingUtil.validateCarModel(str);
			} catch (InvalidCarBookingException e) {}
			assertTrue(flag);

	    }
	    
	    @Test
	    public void test14_ValidateCarModelForBrandHyundai() {
	    	boolean flag=false;
	    	String[] str= {"Exter","Venue"};
			try {
				flag = bookingUtil.validateCarModel(str);
			} catch (InvalidCarBookingException e) {}
			assertTrue(flag);
        }
	    
	    @Test
	    public void test15_ValidateCarModelForInvalidCarModel() {
	    	boolean flag=false;
	    	String[] str= {"Tigo","Safari"};
			try {
				flag = bookingUtil.validateCarModel(str);
				assertTrue(false);
			} catch (InvalidCarBookingException e) {
				assertTrue(true);
			}

	    }
	    
	    @Test
	    public void test16_TotalCountOfCarBookingsByPriceWise() throws InvalidCarBookingException {
	    	boolean flag = false;
	    	try {
	           Map<Double, Integer> result = bookingUtil.totalCountOfCarBookingsByPriceWise();

				if(result.size()==8)
					flag=true;
			} catch (InvalidCarBookingException e) {
			}
			assertTrue(flag);
	
	    }
	    
	    @Test
	    public void test17_TotalCountOfCarBookingsToBeDeliveredOnGivenDate() throws ParseException {
	    	boolean flag = false;
	    	int count = 0;
	    	try {
	    		count = bookingUtil.totalCountOfCarBookingsToBeDeliveredOnGivenDate(df.parse("22/12/2024"));
	    		//System.out.println(count);
	    		if (count == 2) {
	    		//	assertTrue(true); 
					flag = true;
				}
			} catch (InvalidCarBookingException e) {
			}
			assertTrue(flag);   

	    }
	    
	   
	    @Test
	    public void test18_TotalCountOfCarBookingsByPriceWiseForEmptyList() throws InvalidCarBookingException {
	    	boolean flag = false;		
			List<CarBooking> bikeList = new ArrayList<>();
			BookingUtil util2=new BookingUtil();
			util2.setCarBookingList(bikeList);
			try {
				Map<Double, Integer> res = util2.totalCountOfCarBookingsByPriceWise();
			} catch (InvalidCarBookingException e) {
				flag = true;
			}
			assertTrue(flag);
	    }
	    
	    @Test
	    public void test19_TotalCountOfCarBookingsToBeDeliveredOnGivenDateForEmptyList() throws ParseException, InvalidCarBookingException {	 	  	      	  	 	      	      	        	 	
	    	boolean flag = false;
			BookingUtil car=new BookingUtil();
			List<CarBooking> bikeList = new ArrayList<>();
			car.setCarBookingList(bikeList);
			try {
				int count = car.totalCountOfCarBookingsToBeDeliveredOnGivenDate(df.parse("23/12/2025"));
			} catch (InvalidCarBookingException e) {
				flag = true;
			}
			assertTrue(flag);
	
	    }
}

