package com.model;
import java.util.Date;

public class CarBooking {
    private String bookingId;
    private String customerName;
    private String customerNumber;
    private String carBrand;
    private String carModel;
    private Date deliveryDate;
    private double price;
    
    
	public CarBooking() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CarBooking(String bookingId, String customerName, String customerNumber, String carBrand, String carModel,
			Date deliveryDate, double price) {
		super();
		this.bookingId = bookingId;
		this.customerName = customerName;
		this.customerNumber = customerNumber;
		this.carBrand = carBrand;
		this.carModel = carModel;
		this.deliveryDate = deliveryDate;
		this.price = price;
	}
	
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public String getCustomerName() {	 	  	      	  	 	      	      	        	 	
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public String getCarBrand() {
		return carBrand;
	}
	public void setCarBrand(String carBrand) {
		this.carBrand = carBrand;
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public Date getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
    
    
}	 	  	      	  	 	      	      	        	 	
