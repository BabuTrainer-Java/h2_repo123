package com.util;

import com.model.CarBooking;
import com.exception.*;
import java.util.*;

public class BookingUtil {
	private List<CarBooking> carBookingList = new ArrayList<>();

	public List<CarBooking> getCarBookingList() {
		return carBookingList;
	}

	public void setCarBookingList(List<CarBooking> carBookingList) {
		this.carBookingList = carBookingList;
	}

	public boolean validateCarModel(String[] carModels) throws InvalidCarBookingException {
		for (String model : carModels) {
			if (model.equalsIgnoreCase("Swift") || model.equalsIgnoreCase("Baleno") || model.equalsIgnoreCase("Bolero")
					|| model.equalsIgnoreCase("Thar") || model.equalsIgnoreCase("Innova")
					|| model.equalsIgnoreCase("Glanza") || model.equalsIgnoreCase("Exter")
					|| model.equalsIgnoreCase("Venue")) {

				return true;
			}
		}	 	  	      	  	 	      	      	        	 	
		throw new InvalidCarBookingException("Car Model is invalid");

	}

	public Map<Double, Integer> totalCountOfCarBookingsByPriceWise() throws InvalidCarBookingException {
		if (carBookingList.isEmpty()) {
			throw new InvalidCarBookingException("Car booking list is empty");
		}

		Map<Double, Integer> result = new LinkedHashMap<>();

		for (CarBooking carBooking : carBookingList) {
			double carBookingPrice = carBooking.getPrice();
			if (!result.containsKey(carBookingPrice)) {
				result.put(carBookingPrice, 1);
			} else {
				int temp = result.get(carBookingPrice);
				result.put(carBookingPrice, temp + 1);
			}
		}
		return result;
	}

	public int totalCountOfCarBookingsToBeDeliveredOnGivenDate(Date deliveryDate) throws InvalidCarBookingException {
		int count = 0;
		if (carBookingList.size() == 0) {
			throw new InvalidCarBookingException("Car booking list is empty");
		} else {

			for (CarBooking carBooking : carBookingList) {
				if (carBooking.getDeliveryDate().equals(deliveryDate)) {	 	  	      	  	 	      	      	        	 	
					count++;
				}
			}
			return count;
		}
	}
}