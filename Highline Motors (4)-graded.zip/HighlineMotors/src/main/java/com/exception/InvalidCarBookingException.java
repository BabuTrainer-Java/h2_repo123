package com.exception;

public class InvalidCarBookingException extends Exception { 

	public InvalidCarBookingException(String message) {
		super(message);
	}
}