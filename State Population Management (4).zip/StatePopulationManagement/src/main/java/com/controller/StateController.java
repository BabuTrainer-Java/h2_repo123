package com.controller;

import java.util.ArrayList;

import com.model.State;
import com.service.StateService;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.beans.factory.annotation.Autowired;
import com.exception.StateInvalidException;




@RestController
@RequestMapping("/SMS")
public class StateController {
    
    @Autowired
	private StateService stateService;
    
    @PostMapping("/addState")
	public boolean addState(@RequestBody State stateObj)
	{
		return stateService.addState(stateObj);
	}
	
	@GetMapping("/viewStateById/{id}")
	public State viewStateById(@PathVariable("id") Integer stateId) {
	       State state= stateService.viewStateById(stateId);
	       if(state==null){
	           throw new StateInvalidException("State ID "+stateId+" does not exist");
	       }
	       
	       return state;
	}
    
    @GetMapping("/viewStateByCountry/{countryName}")
	public ArrayList<State> viewStateByCountry(@PathVariable String countryName)
	{
		return stateService.viewStateByCountry(countryName);
	}
	
	@PutMapping("updateStatePopulation/{stateId}/{population}")	
	public boolean updateStatePopulation(@PathVariable Integer stateId,@PathVariable long population)
	{
		return stateService.updateStatePopulation(stateId,population);
	}
	
	@DeleteMapping("deleteState/{id}")
	public boolean deleteState(@PathVariable("id") Integer stateId ) 
	{
		return stateService.deleteState(stateId);
	}

}

