package com.test;
import static org.junit.jupiter.api.Assertions.assertTrue;
 
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
 
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
 
import com.exception.InvalidFanOrderException;
import com.model.FanOrder;
import com.util.FanOrderUtil;

public class FanOrderTest {
	
   private static DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    private static List<FanOrder> fanOrders;
    private static FanOrderUtil fanOrderUtil;
 
    @BeforeAll
    public static void setUp() throws ParseException {
    	 FanOrder[] fanOrder = new FanOrder[8];
 
         fanOrder[0] = new FanOrder("ORD123", "Alice", "9876543210", "Orient", "Ceiling Fan", 1500.0, df.parse("14/12/2023"));
         fanOrder[1] = new FanOrder("ORD456", "Bob", "9784567890", "Crompton", "Tower Fan", 2000.0, df.parse("30/12/2023"));
         fanOrder[2] = new FanOrder("ORD789", "Charlie", "8765432109", "Usha", "Table Fan", 800.0, df.parse("03/01/2024"));
         fanOrder[3] = new FanOrder("ORD101", "David", "9870123456", "Havells", "Ceiling Fan", 1800.0, df.parse("22/12/2023"));
         fanOrder[4] = new FanOrder("ORD202", "Eva", "7654321098", "Orient", "Tower Fan", 2200.0, df.parse("11/11/2024"));
         fanOrder[5] = new FanOrder("ORD303", "Frank", "8765098765", "Crompton", "Table Fan", 950.0, df.parse("22/12/2024"));
         fanOrder[6] = new FanOrder("ORD505", "Grace", "7890123456", "Usha", "Ceiling Fan", 1600.0, df.parse("22/12/2024"));
         fanOrder[7] = new FanOrder("ORD606", "Harry", "8765436789", "Havells", "Tower Fan", 2400.0, df.parse("21/09/2023"));
 
         fanOrders = new ArrayList<>(Arrays.asList(fanOrder));
         fanOrderUtil=new FanOrderUtil();
         fanOrderUtil.setFanOrderList(fanOrders);
    }	 	 
	    
    //Test the validateBrandName method when the brandName is Crompton
      @Test
    public void test11_ValidateBrandNameWhenCrompton() throws InvalidFanOrderException {
    	boolean flag = false;
        try {
            flag = fanOrderUtil.validateBrandName("Crompton");
        } catch (InvalidFanOrderException e) {
        }
        assertTrue(flag);
    }
    
    //Test the validateBrandName method when the brandName is Orient
     @Test 
    public void test12_ValidateBrandNameWhenOrient() throws InvalidFanOrderException {
    	boolean flag = false;
        try {
            flag = fanOrderUtil.validateBrandName("Orient");
        } catch (InvalidFanOrderException e) {
        }
        assertTrue(flag);
    }
    
    //Test the validateBrandName method when the brandName is Usha
    @Test  
    public void test13_ValidateBrandNameWhenUsha() throws InvalidFanOrderException {
        boolean flag = false;
        try {
            flag = fanOrderUtil.validateBrandName("Usha");
        } catch (InvalidFanOrderException e) {
        }
        assertTrue(flag);
    }
    
    //Test the validateBrandName method when the brandName is Havells
    @Test  
    public void test14_ValidateBrandNameWhenHavells() throws InvalidFanOrderException {
    	boolean flag = false;
        try {
            flag = fanOrderUtil.validateBrandName("Havells");
        } catch (InvalidFanOrderException e) {
        }
        assertTrue(flag);
    }

    //Test the validateBrandName method when the brandName is invalid
    @Test
    public void test15_ValidateBrandNameWhenInvalid() throws InvalidFanOrderException{
    	boolean flag = false;
        try {
            flag = fanOrderUtil.validateBrandName("Bajaj");
            assertTrue(false);
        } catch (InvalidFanOrderException e) {
        }
        assertTrue(true);
    }    
    
    //Test the viewFanOrderDetailsByBrandName method for a valid brandName
    @Test 
    public void test16_ViewFanOrdersDetailsByBrandName() throws InvalidFanOrderException {
        boolean flag = false;
        int count = 0;
        try {
            List<FanOrder> result = fanOrderUtil.viewFanOrderDetailsByBrandName("Usha");
 
            Iterator<FanOrder> itr = result.iterator();
            while (itr.hasNext()) {
                FanOrder fanOrder = itr.next();
 
                if (fanOrder.getOrderId().equals("ORD789"))
                    count++;
                if (fanOrder.getOrderId().equals("ORD505"))
                    count++;
 
            }
            if (count == 2) {	 	  	      	  	 	      	      	        	 	
                flag = true;
            }
        } catch (InvalidFanOrderException e) {
        }
        assertTrue(flag);
    }
    
    //Test the totalCountOfFanOrdersBasedOnOrderDate method
    @Test 
    public void test17_TotalCountOfFanOrdersBasedOnOrderDate() throws ParseException, InvalidFanOrderException{
    	boolean flag = false;
        int count = 0;
        try {
        	count = fanOrderUtil.totalCountOfFanOrdersBasedOnOrderDate(df.parse("22/12/2024"));
     
            if (count == 2) {	 	  	      	  	 	      	      	        	 	
            	flag=true;
            }
        } catch (InvalidFanOrderException e) {
        }
        assertTrue(flag);
    }
    
    //Test the viewFanOrderDetailsByBrandName method for an empty list
    @Test   
    public void test18_ViewFanOrdersByBrandNameForEmptyList() throws InvalidFanOrderException {
    	boolean flag = false;
        List<FanOrder> orderList = new ArrayList<>();
        FanOrderUtil fo1 = new FanOrderUtil();
        fo1.setFanOrderList(orderList);
        try {
            List<FanOrder> orderList1 = fo1.viewFanOrderDetailsByBrandName("Luminous");
        } catch (InvalidFanOrderException e) {
            flag = true;
        }
        assertTrue(flag);
    //assertTrue(true);
    }

    //Test the totalCountOfFanOrdersBasedOnOrderDate method for an empty list
    @Test
    public void test19_TotalCountOfFanOrdersBasedOnOrderDateForEmptyList() throws ParseException,InvalidFanOrderException  {
      boolean flag = false;
 
        List<FanOrder> orderList = new ArrayList<>();
        FanOrderUtil fo1 = new FanOrderUtil();
        fo1.setFanOrderList(orderList);
        try {
            int result = fo1.totalCountOfFanOrdersBasedOnOrderDate(df.parse("12/11/2022"));
        } catch (InvalidFanOrderException e) {
            flag = true;
        }
        assertTrue(flag);

    }
}