package com.model;
import java.util.*;
public class FanOrder {
	private String orderId;
    private String customerName;
    private String phoneNumber;
    private String brandName; 
    private String fanType; 
    private double price; 
    private Date orderDate;
    
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getFanType() {
		return fanType;
	}	 	  	      	  	 	      	      	        	 	
	public void setFanType(String fanType) {
		this.fanType = fanType;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public FanOrder(String orderId, String customerName, String phoneNumber, String brandName, String fanType,
			double price, Date orderDate) {
		super();
		this.orderId = orderId;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.brandName = brandName;
		this.fanType = fanType;
		this.price = price;
		this.orderDate = orderDate;
	} 
    
    

}
	 	  	      	  	 	      	      	        	 	
