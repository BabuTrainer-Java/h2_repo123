package com.util;
 
import java.util.*;
 
import com.exception.InvalidFanOrderException;
import com.model.FanOrder;
 
public class FanOrderUtil {
	 private List<FanOrder> fanOrderList = new ArrayList<>();
 
		public List<FanOrder> getFanOrderList() {
			return fanOrderList;
		}
 
		public void setFanOrderList(List<FanOrder> fanOrderList) {
			this.fanOrderList = fanOrderList;
		}
 
		public boolean validateBrandName(String brandName) throws InvalidFanOrderException {
 
			if (brandName.equalsIgnoreCase("Crompton") || brandName.equalsIgnoreCase("Orient")
					|| brandName.equalsIgnoreCase("Usha") || brandName.equalsIgnoreCase("Havells")) {
				return true;
			} else {
				throw new InvalidFanOrderException("Brand name is invalid");
			}
		}
 
		public List<FanOrder> viewFanOrderDetailsByBrandName(String brandName) throws InvalidFanOrderException {
			if (fanOrderList.isEmpty()) {
				throw new InvalidFanOrderException("Fan order list is empty");
			}
			List<FanOrder> result = new ArrayList<>();
			for (FanOrder fanOrder : fanOrderList) {
				if (fanOrder.getBrandName().equalsIgnoreCase(brandName)) {
					result.add(fanOrder);
				}
			}
			return result;
		}
 
		public int totalCountOfFanOrdersBasedOnOrderDate(Date orderDate) throws InvalidFanOrderException {
			if (fanOrderList.size() == 0) {
				throw new InvalidFanOrderException("Fan order list is empty");
			}
			int count = 0;
			for (FanOrder fanOrder : fanOrderList) {
				if (fanOrder.getOrderDate().equals(orderDate)) {
					count++;
				}
			}
			return count;
		}
	    
}
	 	  	      	  	 	      	      	        	 	
