package com.exception;

public class InvalidFanOrderException extends Exception {

	public InvalidFanOrderException(String message) {
		super(message);
	}
}
